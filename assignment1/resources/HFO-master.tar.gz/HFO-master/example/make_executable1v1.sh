# Run this file to create an executable of hand_coded_defense_agent.cpp
g++ -c 1v1agent.cpp -I ../src/ -std=c++0x -pthread
g++ -L ../lib/ 1v1agent.o -lhfo -pthread -o 1v1agent  -Wl,-rpath,../lib
