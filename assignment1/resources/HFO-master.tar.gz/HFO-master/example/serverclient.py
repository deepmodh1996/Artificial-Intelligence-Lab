#!/usr/bin/env python
# encoding: utf-8
import subprocess, os, time, shutil, math, random, sys
import numpy as np
from signal import SIGKILL

def server(numagents):
    pros = []
    p1 = None
    p2 = None
    try:
        kwargs = {'stdout':open('./log/'+str(numagents),'w'),
                  'stderr':open('./log/'+str(numagents),'a')}
        cmd = "../bin/HFO --offense-agents " +str(numagents)+ " --defense-npcs "+ str(numagents)+ " --trials 1000 --headless --no-logging --fullstate"
        cmd = os.path.join(cmd)
        p1 = subprocess.Popen(cmd.split(' '), shell=False, **kwargs)
        print 'Instance Launched'
        time.sleep(5)
        if numagents == 1 :
            executable="./1v1agent --numAgents "
        else :
            executable="./2v2agent --numAgents "
        agentCmd = executable + str(numagents) 
        agentCmd = os.path.join(agentCmd)
        p2 = subprocess.Popen(agentCmd.split(' '), shell=False)
        pros.append(p1)
        pros.append(p2)
        p1.communicate()
    except Exception as e:
        print e
        return None
    finally:
        try:
            p1.terminate()
            p1.kill()
        except:
            pass
        try:
            p2.terminate()
            p2.kill()
            time.sleep(5)
        except:
            pass

if __name__ == '__main__':
    server(int(sys.argv[1]))	  
