# Run this file to create an executable of hand_coded_defense_agent.cpp
g++ -c 2v2agent.cpp -I ../src/ -std=c++0x -pthread
g++ -L ../lib/ 2v2agent.o -lhfo -pthread -o 2v2agent  -Wl,-rpath,../lib
