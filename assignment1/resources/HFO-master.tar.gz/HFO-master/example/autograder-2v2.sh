killall -9 rcssserver
./make_executable2v2.sh
python serverclient.py 2
gawk -f logger.awk log/2
