killall -9 rcssserver
./make_executable1v1.sh
python serverclient.py 1
gawk -f logger.awk log/1
